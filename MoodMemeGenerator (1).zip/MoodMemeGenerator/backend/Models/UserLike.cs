namespace MoodMeme.Models;

public class UserLike
{
    public int UserId { get; set; }
    public User User { get; set; } = null!;
    public int MemeId { get; set; }
    public Meme Meme { get; set; } = null!;
    public DateTime LikedAt { get; set; } = DateTime.UtcNow;
}
