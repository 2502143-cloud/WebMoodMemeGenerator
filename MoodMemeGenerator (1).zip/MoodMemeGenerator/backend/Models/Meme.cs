namespace MoodMeme.Models;

public class Meme
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string ImageUrl { get; set; } = string.Empty;
    public string Mood { get; set; } = string.Empty;
    public string Tags { get; set; } = string.Empty;
    public int LikeCount { get; set; } = 0;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public ICollection<UserLike> Likes { get; set; } = new List<UserLike>();
}
