namespace MoodMeme.DTOs;

// Auth DTOs
public record RegisterRequest(string Username, string Email, string Password);
public record LoginRequest(string Email, string Password);
public record AuthResponse(string Token, string Username, string Email, string Role, int UserId);

// Meme DTOs
public record MemeDto(
    int Id,
    string Title,
    string ImageUrl,
    string Mood,
    string Tags,
    int LikeCount,
    bool IsLiked,
    string CreatedAt
);

public record CreateMemeRequest(string Title, string ImageUrl, string Mood, string Tags);

// Feedback DTO
public record FeedbackRequest(string Name, string Email, string Message, int Rating);
