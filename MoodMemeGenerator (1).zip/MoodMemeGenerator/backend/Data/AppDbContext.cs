using Microsoft.EntityFrameworkCore;
using MoodMeme.Models;

namespace MoodMeme.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users { get; set; }
    public DbSet<Meme> Memes { get; set; }
    public DbSet<UserLike> UserLikes { get; set; }
    public DbSet<Feedback> Feedbacks { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Composite PK for UserLike (junction table)
        modelBuilder.Entity<UserLike>()
            .HasKey(ul => new { ul.UserId, ul.MemeId });

        modelBuilder.Entity<UserLike>()
            .HasOne(ul => ul.User)
            .WithMany(u => u.Likes)
            .HasForeignKey(ul => ul.UserId);

        modelBuilder.Entity<UserLike>()
            .HasOne(ul => ul.Meme)
            .WithMany(m => m.Likes)
            .HasForeignKey(ul => ul.MemeId);

        // Unique email constraint
        modelBuilder.Entity<User>()
            .HasIndex(u => u.Email)
            .IsUnique();

        // Seed default admin user (password: Admin@123)
        modelBuilder.Entity<User>().HasData(new User
        {
            Id = 1,
            Username = "admin",
            Email = "admin@moodmeme.com",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@123"),
            Role = "Admin",
            CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc)
        });

        // Seed initial memes
        modelBuilder.Entity<Meme>().HasData(
            new Meme { Id = 1, Title = "Friday Feeling!", ImageUrl = "https://i.imgflip.com/1bij.jpg", Mood = "happy", Tags = "friday,weekend,excited", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 2, Title = "Code Works First Try", ImageUrl = "https://i.imgflip.com/26am.jpg", Mood = "happy", Tags = "coding,success,programmer", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 3, Title = "Payday Arrived!", ImageUrl = "https://i.imgflip.com/1tg14.jpg", Mood = "happy", Tags = "money,payday,celebration", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 4, Title = "Weekend Is Here", ImageUrl = "https://i.imgflip.com/4t0m5.jpg", Mood = "happy", Tags = "weekend,happy,excited", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 5, Title = "Pizza Just Arrived", ImageUrl = "https://i.imgflip.com/1otk96.jpg", Mood = "happy", Tags = "food,pizza,happy", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 6, Title = "Monday Morning Vibes", ImageUrl = "https://i.imgflip.com/1c1uej.jpg", Mood = "sad", Tags = "monday,work,tired", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 7, Title = "Waiting For Text Back", ImageUrl = "https://i.imgflip.com/3si4.jpg", Mood = "sad", Tags = "waiting,text,lonely", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 8, Title = "Out Of Coffee", ImageUrl = "https://i.imgflip.com/2hgfw.jpg", Mood = "sad", Tags = "coffee,morning,sad", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 9, Title = "Budget After Bills", ImageUrl = "https://i.imgflip.com/1ur9b0.jpg", Mood = "sad", Tags = "money,broke,bills", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 10, Title = "Rain On Day Off", ImageUrl = "https://i.imgflip.com/1khwre.jpg", Mood = "sad", Tags = "rain,unlucky,sad", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 11, Title = "Code Breaks After One Change", ImageUrl = "https://i.imgflip.com/1yxkcp.jpg", Mood = "frustrated", Tags = "coding,bug,frustrated", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 12, Title = "Slow Internet On Deadline", ImageUrl = "https://i.imgflip.com/9vct.jpg", Mood = "frustrated", Tags = "internet,slow,deadline", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 13, Title = "Traffic On Friday", ImageUrl = "https://i.imgflip.com/1bhk.jpg", Mood = "frustrated", Tags = "traffic,driving,late", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 14, Title = "Meetings That Could Be Emails", ImageUrl = "https://i.imgflip.com/3uewkg.jpg", Mood = "frustrated", Tags = "meetings,work,email", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
            new Meme { Id = 15, Title = "Printer Needs Ink Again", ImageUrl = "https://i.imgflip.com/2wifvo.jpg", Mood = "frustrated", Tags = "printer,office,annoyed", LikeCount = 0, CreatedAt = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc) }
        );
    }
}
