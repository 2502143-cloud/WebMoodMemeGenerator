using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MoodMeme.Data;
using MoodMeme.DTOs;
using MoodMeme.Models;

namespace MoodMeme.Controllers;

[ApiController]
[Route("api/memes")]
public class MemesController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly HttpClient _http;

    // Imgflip meme IDs mapped by mood
    private static readonly Dictionary<string, string[]> ImgflipMoods = new()
    {
        ["happy"] = new[] { "181913649", "87743020", "112126428", "134797956", "217743513" },
        ["sad"]   = new[] { "61579", "102156234", "28251713", "124822590", "155067746" },
        ["frustrated"] = new[] { "155067746", "247375501", "438680", "4087833", "131940431" }
    };

    public MemesController(AppDbContext db, IHttpClientFactory httpFactory)
    {
        _db = db;
        _http = httpFactory.CreateClient();
    }

    private int? GetUserId()
    {
        var claim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return claim != null ? int.Parse(claim) : null;
    }

    [HttpGet]
    public async Task<ActionResult<List<MemeDto>>> GetMemes([FromQuery] string? mood, [FromQuery] string? search)
    {
        var userId = GetUserId();
        var query = _db.Memes.AsQueryable();

        if (!string.IsNullOrEmpty(mood))
            query = query.Where(m => m.Mood == mood);

        if (!string.IsNullOrEmpty(search))
            query = query.Where(m => m.Title.Contains(search) || m.Tags.Contains(search));

        var memes = await query.OrderByDescending(m => m.LikeCount).ToListAsync();

        HashSet<int> likedIds = new();
        if (userId.HasValue)
        {
            likedIds = (await _db.UserLikes
                .Where(ul => ul.UserId == userId.Value)
                .Select(ul => ul.MemeId)
                .ToListAsync()).ToHashSet();
        }

        return memes.Select(m => ToDto(m, likedIds.Contains(m.Id))).ToList();
    }

    [HttpGet("liked")]
    [Authorize]
    public async Task<ActionResult<List<MemeDto>>> GetLikedMemes([FromQuery] string? mood)
    {
        var userId = GetUserId()!.Value;
        var query = _db.UserLikes
            .Where(ul => ul.UserId == userId)
            .Include(ul => ul.Meme)
            .Select(ul => ul.Meme);

        if (!string.IsNullOrEmpty(mood))
            query = query.Where(m => m.Mood == mood);

        var memes = await query.OrderByDescending(m => m.CreatedAt).ToListAsync();
        return memes.Select(m => ToDto(m, true)).ToList();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<MemeDto>> GetMeme(int id)
    {
        var meme = await _db.Memes.FindAsync(id);
        if (meme == null) return NotFound();
        var userId = GetUserId();
        bool isLiked = userId.HasValue && await _db.UserLikes.AnyAsync(ul => ul.UserId == userId.Value && ul.MemeId == id);
        return ToDto(meme, isLiked);
    }

    [HttpPost("{id}/like")]
    [Authorize]
    public async Task<IActionResult> ToggleLike(int id)
    {
        var userId = GetUserId()!.Value;
        var meme = await _db.Memes.FindAsync(id);
        if (meme == null) return NotFound();

        var existing = await _db.UserLikes.FindAsync(userId, id);
        bool liked;

        if (existing != null)
        {
            _db.UserLikes.Remove(existing);
            meme.LikeCount = Math.Max(0, meme.LikeCount - 1);
            liked = false;
        }
        else
        {
            _db.UserLikes.Add(new UserLike { UserId = userId, MemeId = id });
            meme.LikeCount++;
            liked = true;
        }

        await _db.SaveChangesAsync();
        return Ok(new { liked, likeCount = meme.LikeCount });
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<ActionResult<MemeDto>> CreateMeme([FromBody] CreateMemeRequest req)
    {
        var meme = new Meme
        {
            Title = req.Title,
            ImageUrl = req.ImageUrl,
            Mood = req.Mood,
            Tags = req.Tags
        };
        _db.Memes.Add(meme);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetMeme), new { id = meme.Id }, ToDto(meme, false));
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<ActionResult<MemeDto>> UpdateMeme(int id, [FromBody] CreateMemeRequest req)
    {
        var meme = await _db.Memes.FindAsync(id);
        if (meme == null) return NotFound();

        meme.Title = req.Title;
        meme.ImageUrl = req.ImageUrl;
        meme.Mood = req.Mood;
        meme.Tags = req.Tags;
        await _db.SaveChangesAsync();
        return ToDto(meme, false);
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeleteMeme(int id)
    {
        var meme = await _db.Memes.FindAsync(id);
        if (meme == null) return NotFound();
        _db.Memes.Remove(meme);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpGet("imgflip")]
    public async Task<ActionResult<List<MemeDto>>> GetImgflipMemes([FromQuery] string? mood)
    {
        try
        {
            // Get templates from Imgflip public API
            var resp = await _http.GetFromJsonAsync<ImgflipResponse>("https://api.imgflip.com/get_memes");
            if (resp?.Data?.Memes == null) return Ok(new List<MemeDto>());

            var templates = resp.Data.Memes.Take(100).ToList();

            // Filter by mood using keyword matching
            var moodKeywords = GetMoodKeywords(mood);
            if (moodKeywords.Length > 0)
            {
                templates = templates
                    .Where(t => moodKeywords.Any(k => t.Name.Contains(k, StringComparison.OrdinalIgnoreCase)))
                    .ToList();
            }

            // Limit to 12 results
            var results = templates.Take(12).Select((t, i) => new MemeDto(
                Id: -(i + 1),     // Negative IDs to distinguish from DB memes
                Title: t.Name,
                ImageUrl: t.Url,
                Mood: mood ?? "happy",
                Tags: "imgflip",
                LikeCount: 0,
                IsLiked: false,
                CreatedAt: DateTime.UtcNow.ToString("O")
            )).ToList();

            return Ok(results);
        }
        catch
        {
            return Ok(new List<MemeDto>());
        }
    }

    private static string[] GetMoodKeywords(string? mood) => mood switch
    {
        "happy"      => new[] { "success", "win", "happy", "joy", "good", "best", "smile", "awesome" },
        "sad"        => new[] { "sad", "cry", "alone", "why", "fail", "bad", "miss", "regret" },
        "frustrated" => new[] { "angry", "annoyed", "frustrated", "seriously", "really", "ugh", "why" },
        _ => Array.Empty<string>()
    };

    private static MemeDto ToDto(Meme m, bool isLiked) => new(
        m.Id, m.Title, m.ImageUrl, m.Mood, m.Tags, m.LikeCount, isLiked, m.CreatedAt.ToString("O")
    );
}

// Imgflip API response models
public record ImgflipResponse(ImgflipData? Data);
public record ImgflipData(List<ImgflipTemplate> Memes);
public record ImgflipTemplate(string Id, string Name, string Url, int Width, int Height);
