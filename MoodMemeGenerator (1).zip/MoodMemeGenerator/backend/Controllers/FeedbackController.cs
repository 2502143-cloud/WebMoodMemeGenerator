using Microsoft.AspNetCore.Mvc;
using MoodMeme.Data;
using MoodMeme.DTOs;
using MoodMeme.Models;

namespace MoodMeme.Controllers;

[ApiController]
[Route("api/feedback")]
public class FeedbackController : ControllerBase
{
    private readonly AppDbContext _db;

    public FeedbackController(AppDbContext db) => _db = db;

    [HttpPost]
    public async Task<IActionResult> Submit([FromBody] FeedbackRequest req)
    {
        var feedback = new Feedback
        {
            Name = req.Name,
            Email = req.Email,
            Message = req.Message,
            Rating = Math.Clamp(req.Rating, 1, 5)
        };
        _db.Feedbacks.Add(feedback);
        await _db.SaveChangesAsync();
        return Ok(new { message = "Thank you for your feedback!" });
    }
}
