import { Component, OnInit } from '@angular/core';
import { MemeService, Meme, CreateMeme } from '../Services/meme.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  memes: Meme[] = [];
  loading = false;
  showForm = false;
  editingMeme: Meme | null = null;
  memeForm: FormGroup;
  successMsg = '';
  errorMsg = '';

  moods = ['happy', 'sad', 'frustrated'];

  constructor(private memeService: MemeService, private fb: FormBuilder) {
    this.memeForm = this.fb.group({
      title: ['', Validators.required],
      imageUrl: ['', Validators.required],
      mood: ['happy', Validators.required],
      tags: ['']
    });
  }

  ngOnInit() { this.loadMemes(); }

  loadMemes() {
    this.loading = true;
    this.memeService.getMemes().subscribe({
      next: memes => { this.memes = memes; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  openAdd() {
    this.editingMeme = null;
    this.memeForm.reset({ mood: 'happy' });
    this.showForm = true;
    this.successMsg = '';
    this.errorMsg = '';
  }

  openEdit(meme: Meme) {
    this.editingMeme = meme;
    this.memeForm.patchValue({ title: meme.title, imageUrl: meme.imageUrl, mood: meme.mood, tags: meme.tags });
    this.showForm = true;
    this.successMsg = '';
    this.errorMsg = '';
  }

  cancelForm() { this.showForm = false; this.editingMeme = null; }

  save() {
    if (this.memeForm.invalid) return;
    const data: CreateMeme = this.memeForm.value;
    if (this.editingMeme) {
      this.memeService.updateMeme(this.editingMeme.id, data).subscribe({
        next: () => { this.successMsg = 'Meme updated!'; this.showForm = false; this.loadMemes(); },
        error: () => { this.errorMsg = 'Update failed.'; }
      });
    } else {
      this.memeService.createMeme(data).subscribe({
        next: () => { this.successMsg = 'Meme added!'; this.showForm = false; this.loadMemes(); },
        error: () => { this.errorMsg = 'Create failed.'; }
      });
    }
  }

  delete(id: number) {
    if (!confirm('Delete this meme?')) return;
    this.memeService.deleteMeme(id).subscribe({
      next: () => { this.successMsg = 'Meme deleted.'; this.loadMemes(); },
      error: () => { this.errorMsg = 'Delete failed.'; }
    });
  }
}
