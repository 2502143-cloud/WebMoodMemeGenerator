# MoodMeme Generator

A full-stack web app that maps user moods to curated memes.

## Tech Stack

- **Frontend**: Angular 17 + TypeScript
- **Backend**: ASP.NET Core 8 (C#) — REST API with JWT auth
- **Database**: SQL Server

## Project Structure

```
MoodMemeGenerator/
├── frontend/          ← Angular app
│   ├── src/
│   │   ├── app/
│   │   │   ├── home/                 ← Home page
│   │   │   ├── generate-meme/        ← Browse & filter memes
│   │   │   ├── liked-meme/           ← Saved/liked memes
│   │   │   ├── contact/              ← Contact & feedback
│   │   │   ├── login/                ← Login page
│   │   │   ├── sign-up/              ← Registration
│   │   │   ├── admin/                ← Admin dashboard (CRUD)
│   │   │   ├── Navbar/               ← Navigation bar
│   │   │   ├── footer/               ← Footer
│   │   │   ├── Meme-card/            ← Reusable meme card
│   │   │   ├── Services/             ← AuthService, MemeService, AuthInterceptor
│   │   │   ├── Guards/               ← AuthGuard, AdminGuard
│   │   │   ├── app.module.ts
│   │   │   └── app-routing.module.ts
│   │   ├── environments/
│   │   ├── styles.css
│   │   ├── index.html
│   │   └── main.ts
│   ├── angular.json
│   ├── package.json
│   ├── proxy.conf.json
│   └── tsconfig.json
│
├── backend/           ← ASP.NET Core API
│   ├── Controllers/
│   │   ├── AuthController.cs         ← /api/auth/register, /api/auth/login
│   │   ├── MemesController.cs        ← /api/memes (CRUD + like + imgflip)
│   │   └── FeedbackController.cs     ← /api/feedback
│   ├── Models/
│   │   ├── User.cs
│   │   ├── Meme.cs
│   │   ├── UserLike.cs
│   │   └── Feedback.cs
│   ├── Data/
│   │   └── AppDbContext.cs           ← EF Core DbContext with seed data
│   ├── Services/
│   │   └── TokenService.cs           ← JWT generation
│   ├── DTOs/
│   │   └── Dtos.cs                   ← Request/Response records
│   ├── Properties/
│   │   └── launchSettings.json
│   ├── Program.cs                    ← App startup + middleware
│   ├── appsettings.json
│   └── MoodMeme.csproj
│
└── database/
    ├── setup.sql                     ← Full schema + seed data (SSMS)
    └── SQLQuery1.sql                 ← Original seed script
```

---

## Setup Instructions

### 1. Database (SQL Server)

**Option A — SSMS Script** (easiest):
1. Open SQL Server Management Studio
2. Run `database/setup.sql`
3. Done — database, tables, and seed data are created

**Option B — EF Migrations** (from backend folder):
```bash
dotnet ef migrations add InitialCreate
dotnet ef database update
```

### 2. Backend

```bash
cd backend
dotnet restore
dotnet run
```

The API runs at **http://localhost:5208**
Swagger UI: **http://localhost:5208/swagger**

**Default admin account:**
- Email: `admin@moodmeme.com`
- Password: `Admin@123`

### 3. Frontend

```bash
cd frontend
npm install
npm start
```

App runs at **http://localhost:4200**
The proxy config forwards `/api` calls to `localhost:5208` automatically.

---

## API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | No | Create account |
| POST | `/api/auth/login` | No | Login, get JWT |
| GET | `/api/memes` | No | Get memes (filter by mood/search) |
| GET | `/api/memes/{id}` | No | Get single meme |
| GET | `/api/memes/liked` | User | Get your liked memes |
| POST | `/api/memes/{id}/like` | User | Toggle like |
| POST | `/api/memes` | Admin | Add meme |
| PUT | `/api/memes/{id}` | Admin | Update meme |
| DELETE | `/api/memes/{id}` | Admin | Delete meme |
| GET | `/api/memes/imgflip` | No | Fetch from Imgflip API |
| POST | `/api/feedback` | No | Submit feedback |

---

## Features

- 🎭 **Mood-based meme browsing** — Happy, Sad, Frustrated
- 🔍 **Search** by title or tags
- ❤️ **Like/save** memes (requires login)
- 🌙 **Dark mode** toggle
- 🖼️ **Imgflip integration** — pulls live memes from imgflip.com
- ⚙️ **Admin dashboard** — full CRUD for memes
- 🔐 **JWT authentication** with role-based guards
- 📬 **Contact/Feedback** form

## Team

| Name | Role |
|------|------|
| Meerab Nazir | Frontend |
| Kanzul Emaan | Backend |
| Hafsa Kanwal | Database |
