-- ============================================================
-- MoodMeme Database Setup Script
-- Run this in SQL Server Management Studio (SSMS)
-- ============================================================

-- Create database
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'MoodMemeDB')
BEGIN
    CREATE DATABASE MoodMemeDB;
END
GO

USE MoodMemeDB;
GO

-- ============================================================
-- Tables
-- ============================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Users' AND xtype='U')
BEGIN
    CREATE TABLE Users (
        Id           INT IDENTITY(1,1) PRIMARY KEY,
        Username     NVARCHAR(100) NOT NULL,
        Email        NVARCHAR(200) NOT NULL UNIQUE,
        PasswordHash NVARCHAR(MAX) NOT NULL,
        Role         NVARCHAR(50)  NOT NULL DEFAULT 'User',
        CreatedAt    DATETIME2     NOT NULL DEFAULT GETUTCDATE()
    );
END
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Memes' AND xtype='U')
BEGIN
    CREATE TABLE Memes (
        Id        INT IDENTITY(1,1) PRIMARY KEY,
        Title     NVARCHAR(300) NOT NULL,
        ImageUrl  NVARCHAR(MAX) NOT NULL,
        Mood      NVARCHAR(50)  NOT NULL,
        Tags      NVARCHAR(500) NOT NULL DEFAULT '',
        LikeCount INT           NOT NULL DEFAULT 0,
        CreatedAt DATETIME2     NOT NULL DEFAULT GETUTCDATE()
    );
END
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='UserLikes' AND xtype='U')
BEGIN
    CREATE TABLE UserLikes (
        UserId  INT       NOT NULL REFERENCES Users(Id) ON DELETE CASCADE,
        MemeId  INT       NOT NULL REFERENCES Memes(Id) ON DELETE CASCADE,
        LikedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        PRIMARY KEY (UserId, MemeId)
    );
END
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Feedbacks' AND xtype='U')
BEGIN
    CREATE TABLE Feedbacks (
        Id        INT IDENTITY(1,1) PRIMARY KEY,
        Name      NVARCHAR(200) NOT NULL,
        Email     NVARCHAR(200) NOT NULL DEFAULT '',
        Message   NVARCHAR(MAX) NOT NULL,
        Rating    INT           NOT NULL DEFAULT 5,
        CreatedAt DATETIME2     NOT NULL DEFAULT GETUTCDATE()
    );
END
GO

-- EF Migrations history table (needed if using dotnet ef migrations)
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='__EFMigrationsHistory' AND xtype='U')
BEGIN
    CREATE TABLE __EFMigrationsHistory (
        MigrationId    NVARCHAR(150) NOT NULL PRIMARY KEY,
        ProductVersion NVARCHAR(32)  NOT NULL
    );
END
GO

-- ============================================================
-- Seed Data
-- ============================================================

-- Default admin user (password: Admin@123 — BCrypt hash)
IF NOT EXISTS (SELECT 1 FROM Users WHERE Email = 'admin@moodmeme.com')
BEGIN
    INSERT INTO Users (Username, Email, PasswordHash, Role, CreatedAt) VALUES
    ('admin', 'admin@moodmeme.com',
     '$2a$11$3VGxNoxSiZkJiVyj.ZyIVOI5Bpu.4cHe9u3hQWKw7TZBfJ7.9WkNq',
     'Admin', '2024-01-01');
END
GO

-- Seed memes
DELETE FROM Memes;
GO

INSERT INTO Memes (Title, ImageUrl, Mood, Tags, LikeCount, CreatedAt) VALUES
('Friday Feeling!', 'https://i.imgflip.com/1bij.jpg', 'happy', 'friday,weekend,excited', 0, GETUTCDATE()),
('Code Works First Try', 'https://i.imgflip.com/26am.jpg', 'happy', 'coding,success,programmer', 0, GETUTCDATE()),
('Payday Arrived!', 'https://i.imgflip.com/1tg14.jpg', 'happy', 'money,payday,celebration', 0, GETUTCDATE()),
('Weekend Is Here', 'https://i.imgflip.com/4t0m5.jpg', 'happy', 'weekend,happy,excited', 0, GETUTCDATE()),
('Pizza Just Arrived', 'https://i.imgflip.com/1otk96.jpg', 'happy', 'food,pizza,happy', 0, GETUTCDATE()),
('Monday Morning Vibes', 'https://i.imgflip.com/1c1uej.jpg', 'sad', 'monday,work,tired', 0, GETUTCDATE()),
('Waiting For Text Back', 'https://i.imgflip.com/3si4.jpg', 'sad', 'waiting,text,lonely', 0, GETUTCDATE()),
('Out Of Coffee', 'https://i.imgflip.com/2hgfw.jpg', 'sad', 'coffee,morning,sad', 0, GETUTCDATE()),
('Budget After Bills', 'https://i.imgflip.com/1ur9b0.jpg', 'sad', 'money,broke,bills', 0, GETUTCDATE()),
('Rain On Day Off', 'https://i.imgflip.com/1khwre.jpg', 'sad', 'rain,unlucky,sad', 0, GETUTCDATE()),
('Code Breaks After One Change', 'https://i.imgflip.com/1yxkcp.jpg', 'frustrated', 'coding,bug,frustrated', 0, GETUTCDATE()),
('Slow Internet On Deadline', 'https://i.imgflip.com/9vct.jpg', 'frustrated', 'internet,slow,deadline', 0, GETUTCDATE()),
('Traffic On Friday', 'https://i.imgflip.com/1bhk.jpg', 'frustrated', 'traffic,driving,late', 0, GETUTCDATE()),
('Meetings That Could Be Emails', 'https://i.imgflip.com/3uewkg.jpg', 'frustrated', 'meetings,work,email', 0, GETUTCDATE()),
('Printer Needs Ink Again', 'https://i.imgflip.com/2wifvo.jpg', 'frustrated', 'printer,office,annoyed', 0, GETUTCDATE());
GO

PRINT 'MoodMemeDB setup complete!';
GO
